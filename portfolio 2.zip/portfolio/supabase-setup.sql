-- Run in Supabase Dashboard -> SQL Editor

CREATE TABLE public.contact_messages (
    id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name       TEXT NOT NULL,
    email      TEXT NOT NULL,
    subject    TEXT NOT NULL,
    message    TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.contact_messages ENABLE ROW LEVEL SECURITY;

-- Anonymous visitors may INSERT only, and only valid-looking rows.
CREATE POLICY "Allow public contact form submissions"
ON public.contact_messages
FOR INSERT
TO anon
WITH CHECK (
    char_length(trim(name))    BETWEEN 2 AND 100
    AND char_length(email)     BETWEEN 5 AND 254
    AND char_length(trim(subject)) BETWEEN 2 AND 150
    AND char_length(trim(message)) BETWEEN 10 AND 5000
);

-- Make the privileges explicit: INSERT only. No SELECT / UPDATE / DELETE for anon.
REVOKE ALL ON public.contact_messages FROM anon;
GRANT INSERT ON public.contact_messages TO anon;
